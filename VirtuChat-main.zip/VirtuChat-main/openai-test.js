
async function main() {
  console.log(process.env.OPENAI_API_KEY);
}

main();